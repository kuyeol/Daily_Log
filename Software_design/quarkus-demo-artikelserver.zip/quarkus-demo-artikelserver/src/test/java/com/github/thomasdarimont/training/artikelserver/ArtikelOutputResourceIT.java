package com.github.thomasdarimont.training.artikelserver;

import io.quarkus.test.junit.QuarkusIntegrationTest;

@QuarkusIntegrationTest
public class ArtikelOutputResourceIT extends ArtikelOutputResourceTest {
    // Execute the same tests but in packaged mode.
}
