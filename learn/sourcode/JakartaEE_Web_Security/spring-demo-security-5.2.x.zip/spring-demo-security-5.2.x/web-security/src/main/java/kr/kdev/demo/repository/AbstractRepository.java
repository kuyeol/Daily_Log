package kr.kdev.demo.repository;

public abstract class AbstractRepository {
}
