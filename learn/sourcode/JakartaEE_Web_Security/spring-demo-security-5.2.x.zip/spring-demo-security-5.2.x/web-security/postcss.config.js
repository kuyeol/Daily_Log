module.exports = {
    plugins: [
        require('postcss-cssnext'),
        require('precss'),
        require('autoprefixer'),
        require('cssnano')
    ]
}